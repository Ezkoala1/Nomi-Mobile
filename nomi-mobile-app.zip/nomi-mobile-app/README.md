# ⚡ Nomi Mobile

A React Native / Expo mobile app starter for Nomi.

## Generate

```bash
python generate_nomi.py
cd nomi-mobile-app
npm install
cp .env.example .env
npx expo start
```

Add your existing public Supabase client configuration to `.env`.

Never put service-role keys, database passwords, or other private secrets in the app.
