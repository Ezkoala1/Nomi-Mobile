# Nomi Mobile

React Native / Expo mobile app for the existing Nomi Supabase project.

## Generate

Run:

```bash
python generate_nomi.py
```

Then:

```bash
cd nomi-mobile-app
npm install
npx expo start
```

## Environment

Create `nomi-mobile-app/.env`:

```env
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_SUPABASE_PUBLISHABLE_KEY
```

These are public client-side variables. Never put a Supabase service-role key or database password in the app.

## APK

```bash
eas build --platform android --profile preview
```

The `preview` profile is configured to produce an APK.

## Schema

The app matches the supplied tables:

- profiles
- posts
- follows
- conversations
- conversation_members
- messages

Media selection is included, but actual Supabase Storage uploading is not guessed because the bucket name/policies were not supplied.
