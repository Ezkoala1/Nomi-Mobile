import { createClient } from "@supabase/supabase-js";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!url || !key) {
  console.warn("Copy .env.example to .env and add your public Supabase client credentials.");
}

export const supabase = createClient(
  url || "https://placeholder.supabase.co",
  key || "placeholder"
);
