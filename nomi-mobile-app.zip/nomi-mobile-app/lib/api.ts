import { supabase } from "./supabase";

export async function getCurrentProfile() {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return null;

  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", auth.user.id)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function searchProfiles(query: string) {
  const q = query.trim();
  if (!q) return [];

  const { data, error } = await supabase
    .from("profiles")
    .select("id, username, display_name, avatar_url, verified, is_verified")
    .ilike("username", `%${q}%`)
    .limit(20);

  if (error) throw error;
  return data ?? [];
}

export async function getFeed() {
  const { data, error } = await supabase
    .from("posts")
    .select(`
      id,
      user_id,
      content,
      media_url,
      media_type,
      created_at,
      profiles:user_id (
        username,
        display_name,
        avatar_url,
        verified,
        is_verified
      )
    `)
    .order("created_at", { ascending: false })
    .limit(30);

  if (error) throw error;
  return data ?? [];
}

export async function getMyConversations() {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return [];

  const { data: memberships, error: membershipError } = await supabase
    .from("conversation_members")
    .select("conversation_id")
    .eq("user_id", auth.user.id);

  if (membershipError) throw membershipError;

  const ids = (memberships ?? []).map((m) => m.conversation_id);
  if (!ids.length) return [];

  const { data, error } = await supabase
    .from("conversations")
    .select("id, name, created_at")
    .in("id", ids)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function getMessages(conversationId: string) {
  const { data, error } = await supabase
    .from("messages")
    .select("id, conversation_id, sender_id, content, created_at")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });

  if (error) throw error;
  return data ?? [];
}
