import { supabase } from "./supabase";

export async function getCurrentProfile() {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return null;
  const { data, error } = await supabase.from("profiles").select("*")
    .eq("id", auth.user.id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function searchProfiles(query: string) {
  if (!query.trim()) return [];
  const { data, error } = await supabase.from("profiles")
    .select("id, username, display_name, avatar_url, is_verified")
    .ilike("username", `%${query.trim()}%`).limit(20);
  if (error) throw error;
  return data ?? [];
}

export async function getFeed() {
  const { data, error } = await supabase.from("posts").select("*")
    .order("created_at", { ascending: false }).limit(30);
  if (error) throw error;
  return data ?? [];
}
