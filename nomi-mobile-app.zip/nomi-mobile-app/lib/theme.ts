export const colors = {
  bg: "#070b18",
  panel: "#0d1326",
  panel2: "#111a32",
  border: "#202b4a",
  text: "#f4f5ff",
  muted: "#8993b0",
  purple: "#9b6cff",
  blue: "#456cff",
  danger: "#ff5f72",
  success: "#5bd68a",
};

export const radius = {
  sm: 10,
  md: 14,
  lg: 20,
  xl: 26,
};
