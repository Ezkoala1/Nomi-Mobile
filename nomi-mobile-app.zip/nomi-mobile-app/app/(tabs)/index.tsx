import React, { useCallback, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";
import { Screen } from "../../components/Screen";
import { Brand } from "../../components/Brand";
import { PostCard } from "../../components/PostCard";
import { getFeed } from "../../lib/api";
import { colors } from "../../lib/theme";

export default function Home() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setPosts(await getFeed());
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <Screen>
      <View style={styles.header}>
        <Brand />
        <Text style={styles.heading}>Your feed</Text>
      </View>

      {loading ? (
        <ActivityIndicator color={colors.purple} style={{ marginTop: 40 }} />
      ) : posts.length ? (
        posts.map((p) => <PostCard key={p.id} post={p} />)
      ) : (
        <View style={styles.empty}>
          <Text style={styles.emptyTitle}>Nothing here yet</Text>
          <Text style={styles.emptyText}>Follow people and their posts will appear here.</Text>
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { marginBottom: 22 },
  heading: { color: colors.text, fontSize: 28, fontWeight: "800", marginTop: 22 },
  empty: { padding: 30, alignItems: "center" },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: "800" },
  emptyText: { color: colors.muted, textAlign: "center", marginTop: 8, lineHeight: 20 },
});
