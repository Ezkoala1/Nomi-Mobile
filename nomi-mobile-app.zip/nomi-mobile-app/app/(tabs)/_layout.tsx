import React from "react";
import { Tabs } from "expo-router";
import { Text } from "react-native";
import { colors } from "../../lib/theme";

const Icon = ({ value }: { value: string }) => (
  <Text style={{ fontSize: 22 }}>{value}</Text>
);

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.panel,
          borderTopColor: colors.border,
          height: 78,
          paddingTop: 8,
        },
        tabBarActiveTintColor: colors.purple,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 11, fontWeight: "700" },
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: () => <Icon value="⌂" /> }} />
      <Tabs.Screen name="discover" options={{ title: "Discover", tabBarIcon: () => <Icon value="⌕" /> }} />
      <Tabs.Screen name="create" options={{ title: "Create", tabBarIcon: () => <Icon value="＋" /> }} />
      <Tabs.Screen name="messages" options={{ title: "Messages", tabBarIcon: () => <Icon value="◌" /> }} />
      <Tabs.Screen name="profile" options={{ title: "Profile", tabBarIcon: () => <Icon value="○" /> }} />
    </Tabs>
  );
}
