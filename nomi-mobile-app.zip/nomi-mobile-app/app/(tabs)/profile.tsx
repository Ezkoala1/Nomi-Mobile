import React from "react";
import { Alert,StyleSheet,Text,TouchableOpacity,View } from "react-native";
import { Screen } from "../../components/Screen";
import { useAuth } from "../../context/AuthContext";
import { supabase } from "../../lib/supabase";
import { colors,radius } from "../../lib/theme";

export default function Profile(){
  const {user}=useAuth();
  async function logout(){const {error}=await supabase.auth.signOut();if(error)Alert.alert("Unable to log out",error.message);}
  return <Screen><Text style={styles.title}>Your profile</Text><View style={styles.card}>
    <View style={styles.avatar}><Text style={styles.avatarText}>N</Text></View><Text style={styles.name}>Nomi user</Text><Text style={styles.email}>{user?.email||""}</Text>
  </View><TouchableOpacity style={styles.button} onPress={logout}><Text style={styles.buttonText}>Log out</Text></TouchableOpacity></Screen>;
}
const styles=StyleSheet.create({
  title:{color:colors.text,fontSize:29,fontWeight:"800",marginBottom:20},
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.lg,padding:22,alignItems:"center"},
  avatar:{width:78,height:78,borderRadius:39,backgroundColor:colors.purple,alignItems:"center",justifyContent:"center",marginBottom:14},
  avatarText:{color:"white",fontSize:28,fontWeight:"800"},name:{color:colors.text,fontSize:20,fontWeight:"800"},email:{color:colors.muted,marginTop:5},
  button:{marginTop:14,padding:15,borderRadius:radius.md,backgroundColor:colors.panel2,borderColor:colors.border,borderWidth:1,alignItems:"center"},buttonText:{color:colors.danger,fontWeight:"800"}
});
