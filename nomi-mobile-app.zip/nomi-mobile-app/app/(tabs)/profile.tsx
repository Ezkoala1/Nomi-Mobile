import React, { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { Screen } from "../../components/Screen";
import { useAuth } from "../../context/AuthContext";
import { getCurrentProfile } from "../../lib/api";
import { supabase } from "../../lib/supabase";
import { colors, radius } from "../../lib/theme";

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    try {
      const data = await getCurrentProfile();
      setProfile(data);
      setUsername(data?.username || "");
      setDisplayName(data?.display_name || "");
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  }

  async function saveProfile() {
    if (!user) return;

    if (!username.trim()) {
      Alert.alert("Username required", "Please enter a username.");
      return;
    }

    setBusy(true);

    const { data, error } = await supabase
      .from("profiles")
      .update({
        username: username.trim(),
        display_name: displayName.trim() || null,
      })
      .eq("id", user.id)
      .select("*")
      .maybeSingle();

    setBusy(false);

    if (error) {
      Alert.alert("Could not save", error.message);
      return;
    }

    setProfile(data);
    Alert.alert("Saved", "Your profile has been updated.");
  }

  async function logout() {
    const { error } = await supabase.auth.signOut();
    if (error) Alert.alert("Unable to log out", error.message);
  }

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.purple} />
      </View>
    );
  }

  return (
    <Screen>
      <Text style={styles.title}>Your profile</Text>

      <View style={styles.card}>
        {profile?.avatar_url ? (
          <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
        ) : (
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{(displayName || username || "N")[0].toUpperCase()}</Text>
          </View>
        )}

        <Text style={styles.email}>{user?.email || ""}</Text>

        <TextInput
          style={styles.input}
          value={displayName}
          onChangeText={setDisplayName}
          placeholder="Display name"
          placeholderTextColor={colors.muted}
        />

        <TextInput
          style={styles.input}
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          placeholder="Username"
          placeholderTextColor={colors.muted}
        />

        <TouchableOpacity style={styles.save} onPress={saveProfile} disabled={busy}>
          <Text style={styles.saveText}>{busy ? "Saving..." : "Save profile"}</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Log out</Text>
      </TouchableOpacity>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1, backgroundColor: colors.bg, alignItems: "center", justifyContent: "center",
  },
  title: { color: colors.text, fontSize: 29, fontWeight: "800", marginBottom: 20 },
  card: {
    backgroundColor: colors.panel, borderColor: colors.border, borderWidth: 1,
    borderRadius: radius.lg, padding: 22, alignItems: "center",
  },
  avatar: {
    width: 86, height: 86, borderRadius: 43, backgroundColor: colors.purple,
    alignItems: "center", justifyContent: "center", marginBottom: 14,
  },
  avatarText: { color: "white", fontSize: 30, fontWeight: "800" },
  email: { color: colors.muted, marginBottom: 16 },
  input: {
    width: "100%", backgroundColor: colors.bg, borderColor: colors.border,
    borderWidth: 1, borderRadius: radius.md, color: colors.text,
    padding: 13, marginBottom: 10,
  },
  save: {
    width: "100%", backgroundColor: colors.purple, borderRadius: radius.md,
    padding: 14, alignItems: "center", marginTop: 4,
  },
  saveText: { color: "white", fontWeight: "800" },
  logout: {
    marginTop: 14, padding: 15, borderRadius: radius.md,
    backgroundColor: colors.panel2, borderColor: colors.border,
    borderWidth: 1, alignItems: "center",
  },
  logoutText: { color: colors.danger, fontWeight: "800" },
});
