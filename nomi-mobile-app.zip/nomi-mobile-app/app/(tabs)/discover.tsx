import React, { useState } from "react";
import { ActivityIndicator, Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "../../components/Screen";
import { searchProfiles } from "../../lib/api";
import { colors, radius } from "../../lib/theme";

export default function Discover() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function search(v: string) {
    setQuery(v);
    if (!v.trim()) {
      setResults([]);
      return;
    }

    setLoading(true);
    try {
      setResults(await searchProfiles(v));
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Screen>
      <Text style={styles.title}>Discover</Text>
      <Text style={styles.subtitle}>Find people on Nomi.</Text>

      <TextInput
        style={styles.input}
        placeholder="Search usernames..."
        placeholderTextColor={colors.muted}
        autoCapitalize="none"
        autoCorrect={false}
        value={query}
        onChangeText={search}
      />

      {loading && <ActivityIndicator color={colors.purple} style={{ marginBottom: 12 }} />}

      {results.map((p) => (
        <TouchableOpacity
          key={p.id}
          style={styles.person}
          onPress={() => router.push(`/user/${p.username}`)}
        >
          {p.avatar_url ? (
            <Image source={{ uri: p.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{(p.display_name || p.username || "N")[0].toUpperCase()}</Text>
            </View>
          )}

          <View style={{ flex: 1 }}>
            <Text style={styles.name}>{p.display_name || p.username}</Text>
            <Text style={styles.username}>@{p.username}</Text>
          </View>

          {(p.verified || p.is_verified) && <Text style={styles.verified}>✓</Text>}
          <Text style={styles.arrow}>›</Text>
        </TouchableOpacity>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 29, fontWeight: "800" },
  subtitle: { color: colors.muted, marginTop: 6, marginBottom: 20 },
  input: {
    backgroundColor: colors.panel, borderColor: colors.border, borderWidth: 1,
    borderRadius: radius.md, color: colors.text, padding: 14, marginBottom: 14,
  },
  person: {
    flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.panel,
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.md,
    padding: 13, marginBottom: 10,
  },
  avatar: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: colors.purple,
    alignItems: "center", justifyContent: "center",
  },
  avatarText: { color: "white", fontWeight: "800" },
  name: { color: colors.text, fontWeight: "800" },
  username: { color: colors.muted, marginTop: 2 },
  verified: { color: colors.purple, fontWeight: "900", fontSize: 17 },
  arrow: { color: colors.muted, fontSize: 26 },
});
