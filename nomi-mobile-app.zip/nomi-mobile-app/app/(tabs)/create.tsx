import React,{useState} from "react";
import { Alert,Image,StyleSheet,Text,TextInput,TouchableOpacity } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { Screen } from "../../components/Screen";
import { supabase } from "../../lib/supabase";
import { colors,radius } from "../../lib/theme";

export default function Create(){
  const [text,setText]=useState(""); const [imageUri,setImageUri]=useState<string|null>(null); const [busy,setBusy]=useState(false);
  async function chooseImage(){
    const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:["images","videos"],quality:.85});
    if(!result.canceled)setImageUri(result.assets[0].uri);
  }
  async function publish(){
    if(!text.trim()&&!imageUri)return Alert.alert("Add something first","Write something or choose an image/video.");
    setBusy(true);
    try{
      const {data:u}=await supabase.auth.getUser();if(!u.user)throw new Error("You are not logged in.");
      const {error}=await supabase.from("posts").insert({user_id:u.user.id,content:text.trim()||null});
      if(error)throw error;setText("");setImageUri(null);Alert.alert("Posted","Your post is now live.");
    }catch(e:any){Alert.alert("Could not post",e?.message||"Something went wrong.");}finally{setBusy(false);}
  }
  return <Screen><Text style={styles.title}>Create a post</Text><Text style={styles.subtitle}>Share something with your followers.</Text>
    <TextInput style={styles.composer} placeholder="What's happening?" placeholderTextColor={colors.muted} multiline value={text} onChangeText={setText}/>
    {imageUri&&<Image source={{uri:imageUri}} style={styles.preview}/>}
    <TouchableOpacity style={styles.secondary} onPress={chooseImage}><Text style={styles.secondaryText}>📷 Add photo or video</Text></TouchableOpacity>
    <TouchableOpacity style={styles.primary} onPress={publish} disabled={busy}><Text style={styles.primaryText}>{busy?"Posting...":"Post"}</Text></TouchableOpacity>
  </Screen>;
}
const styles=StyleSheet.create({
  title:{color:colors.text,fontSize:29,fontWeight:"800"},subtitle:{color:colors.muted,marginTop:6,marginBottom:20},
  composer:{minHeight:170,backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.lg,color:colors.text,padding:16,textAlignVertical:"top"},
  preview:{width:"100%",height:240,borderRadius:radius.md,marginTop:14},secondary:{borderColor:colors.border,borderWidth:1,backgroundColor:colors.panel2,padding:14,borderRadius:radius.md,alignItems:"center",marginTop:12},
  secondaryText:{color:colors.text,fontWeight:"700"},primary:{backgroundColor:colors.purple,padding:15,borderRadius:radius.md,alignItems:"center",marginTop:12},primaryText:{color:"white",fontWeight:"800"}
});
