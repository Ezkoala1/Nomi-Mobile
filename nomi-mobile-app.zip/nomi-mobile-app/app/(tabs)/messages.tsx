import React from "react";
import { StyleSheet,Text,TouchableOpacity,View } from "react-native";
import { router } from "expo-router";
import { Screen } from "../../components/Screen";
import { colors,radius } from "../../lib/theme";

export default function Messages(){
  return <Screen><Text style={styles.title}>Messages</Text><Text style={styles.subtitle}>Your conversations.</Text>
    <TouchableOpacity style={styles.conversation} onPress={()=>router.push("/chat/demo")}>
      <View style={styles.avatar}><Text style={styles.avatarText}>N</Text></View>
      <View style={{flex:1}}><Text style={styles.name}>Your conversations</Text><Text style={styles.preview}>Open your messages</Text></View>
      <Text style={styles.arrow}>›</Text>
    </TouchableOpacity>
  </Screen>;
}
const styles=StyleSheet.create({
  title:{color:colors.text,fontSize:29,fontWeight:"800"},subtitle:{color:colors.muted,marginTop:6,marginBottom:20},
  conversation:{flexDirection:"row",alignItems:"center",gap:12,backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.md,padding:13},
  avatar:{width:46,height:46,borderRadius:23,backgroundColor:colors.purple,alignItems:"center",justifyContent:"center"},
  avatarText:{color:"white",fontWeight:"800"},name:{color:colors.text,fontWeight:"800"},preview:{color:colors.muted,marginTop:3},arrow:{color:colors.muted,fontSize:26}
});
