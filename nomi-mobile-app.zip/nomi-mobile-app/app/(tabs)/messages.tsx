import React, { useCallback, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useFocusEffect, router } from "expo-router";
import { Screen } from "../../components/Screen";
import { getMyConversations } from "../../lib/api";
import { colors, radius } from "../../lib/theme";

export default function Messages() {
  const [conversations, setConversations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setConversations(await getMyConversations());
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <Screen>
      <Text style={styles.title}>Messages</Text>
      <Text style={styles.subtitle}>Your conversations.</Text>

      {loading ? (
        <ActivityIndicator color={colors.purple} />
      ) : conversations.length ? (
        conversations.map((conversation) => (
          <TouchableOpacity
            key={conversation.id}
            style={styles.conversation}
            onPress={() => router.push(`/chat/${conversation.id}`)}
          >
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{(conversation.name || "N")[0].toUpperCase()}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{conversation.name || "Conversation"}</Text>
              <Text style={styles.preview}>Open conversation</Text>
            </View>
            <Text style={styles.arrow}>›</Text>
          </TouchableOpacity>
        ))
      ) : (
        <View style={styles.empty}>
          <Text style={styles.emptyTitle}>No conversations yet</Text>
          <Text style={styles.emptyText}>Your conversations will appear here.</Text>
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 29, fontWeight: "800" },
  subtitle: { color: colors.muted, marginTop: 6, marginBottom: 20 },
  conversation: {
    flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.panel,
    borderColor: colors.border, borderWidth: 1, borderRadius: radius.md,
    padding: 13, marginBottom: 10,
  },
  avatar: {
    width: 46, height: 46, borderRadius: 23, backgroundColor: colors.purple,
    alignItems: "center", justifyContent: "center",
  },
  avatarText: { color: "white", fontWeight: "800" },
  name: { color: colors.text, fontWeight: "800" },
  preview: { color: colors.muted, marginTop: 3 },
  arrow: { color: colors.muted, fontSize: 26 },
  empty: { padding: 30, alignItems: "center" },
  emptyTitle: { color: colors.text, fontWeight: "800", fontSize: 18 },
  emptyText: { color: colors.muted, textAlign: "center", marginTop: 8 },
});
