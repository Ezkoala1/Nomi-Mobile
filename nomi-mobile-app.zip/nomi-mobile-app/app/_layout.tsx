import React from "react";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { AuthProvider } from "../context/AuthContext";
import { colors } from "../lib/theme";

export default function Layout() {
  return <AuthProvider><StatusBar style="light"/><Stack screenOptions={{
    headerStyle:{backgroundColor:colors.bg},headerTintColor:colors.text,
    headerShadowVisible:false,contentStyle:{backgroundColor:colors.bg}
  }}/></AuthProvider>;
}
