import React from "react";
import { ActivityIndicator, StyleSheet, View } from "react-native";
import { Redirect } from "expo-router";
import { useAuth } from "../context/AuthContext";
import { colors } from "../lib/theme";

export default function Index(){
  const {user,loading}=useAuth();
  if(loading)return <View style={styles.loading}><ActivityIndicator color={colors.purple} size="large"/></View>;
  return <Redirect href={user?"/(tabs)":"/auth/login"}/>;
}
const styles=StyleSheet.create({loading:{flex:1,backgroundColor:colors.bg,alignItems:"center",justifyContent:"center"}});
