import React,{useState} from "react";
import { Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { router } from "expo-router";
import { Brand } from "../../components/Brand";
import { supabase } from "../../lib/supabase";
import { colors,radius } from "../../lib/theme";

export default function Login(){
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [busy,setBusy]=useState(false);
  async function login(){
    setBusy(true); const {error}=await supabase.auth.signInWithPassword({email,password}); setBusy(false);
    if(error)return Alert.alert("Unable to log in",error.message); router.replace("/(tabs)");
  }
  return <View style={styles.page}><Brand/><Text style={styles.subtitle}>A simple place to message your people.</Text>
    <TextInput style={styles.input} placeholder="Email" placeholderTextColor={colors.muted} keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail}/>
    <TextInput style={styles.input} placeholder="Password" placeholderTextColor={colors.muted} secureTextEntry value={password} onChangeText={setPassword}/>
    <TouchableOpacity style={styles.primary} onPress={login} disabled={busy}><Text style={styles.primaryText}>{busy?"Please wait...":"Log in"}</Text></TouchableOpacity>
    <TouchableOpacity onPress={()=>router.push("/auth/signup")} style={styles.linkButton}><Text style={styles.link}>Create an account</Text></TouchableOpacity>
  </View>;
}
const styles=StyleSheet.create({
  page:{flex:1,backgroundColor:colors.bg,padding:24,justifyContent:"center"},
  subtitle:{color:colors.muted,marginTop:12,marginBottom:28,lineHeight:21},
  input:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.md,color:colors.text,padding:14,marginBottom:12},
  primary:{backgroundColor:colors.purple,borderRadius:radius.md,padding:15,alignItems:"center"},
  primaryText:{color:"white",fontWeight:"800"},linkButton:{alignItems:"center",marginTop:18},link:{color:colors.purple,fontWeight:"700"}
});
