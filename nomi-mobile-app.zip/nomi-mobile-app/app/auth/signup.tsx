import React,{useState} from "react";
import { Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { router } from "expo-router";
import { Brand } from "../../components/Brand";
import { supabase } from "../../lib/supabase";
import { colors,radius } from "../../lib/theme";

export default function Signup(){
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [busy,setBusy]=useState(false);
  async function signup(){
    setBusy(true); const {data,error}=await supabase.auth.signUp({email,password}); setBusy(false);
    if(error)return Alert.alert("Unable to sign up",error.message);
    if(!data.session)return Alert.alert("Check your inbox","Confirm your email to finish creating your account.");
    router.replace("/(tabs)");
  }
  return <View style={styles.page}><Brand/><Text style={styles.title}>Create your Nomi account</Text>
    <TextInput style={styles.input} placeholder="Email" placeholderTextColor={colors.muted} keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail}/>
    <TextInput style={styles.input} placeholder="Password" placeholderTextColor={colors.muted} secureTextEntry value={password} onChangeText={setPassword}/>
    <TouchableOpacity style={styles.primary} onPress={signup} disabled={busy}><Text style={styles.primaryText}>{busy?"Creating...":"Create account"}</Text></TouchableOpacity>
  </View>;
}
const styles=StyleSheet.create({
  page:{flex:1,backgroundColor:colors.bg,padding:24,justifyContent:"center"},
  title:{color:colors.text,fontSize:22,fontWeight:"800",marginVertical:22},
  input:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.md,color:colors.text,padding:14,marginBottom:12},
  primary:{backgroundColor:colors.purple,borderRadius:radius.md,padding:15,alignItems:"center"},primaryText:{color:"white",fontWeight:"800"}
});
