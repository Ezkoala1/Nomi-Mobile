import React, { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../../components/Screen";
import { supabase } from "../../lib/supabase";
import { colors, radius } from "../../lib/theme";

export default function UserProfile() {
  const { username } = useLocalSearchParams<{ username: string }>();
  const [profile, setProfile] = useState<any>(null);
  const [following, setFollowing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, [username]);

  async function load() {
    if (!username) return;
    setLoading(true);

    try {
      const { data: found, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("username", username)
        .maybeSingle();

      if (error) throw error;
      setProfile(found);

      const { data: auth } = await supabase.auth.getUser();

      if (auth.user && found) {
        const { data: follow } = await supabase
          .from("follows")
          .select("follower_id")
          .eq("follower_id", auth.user.id)
          .eq("following_id", found.id)
          .maybeSingle();

        setFollowing(!!follow);
      }
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  }

  async function toggleFollow() {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user || !profile) return;

    if (auth.user.id === profile.id) {
      Alert.alert("That's you", "You cannot follow your own profile.");
      return;
    }

    if (following) {
      const { error } = await supabase
        .from("follows")
        .delete()
        .eq("follower_id", auth.user.id)
        .eq("following_id", profile.id);

      if (error) {
        Alert.alert("Could not unfollow", error.message);
        return;
      }

      setFollowing(false);
    } else {
      const { error } = await supabase.from("follows").insert({
        follower_id: auth.user.id,
        following_id: profile.id,
      });

      if (error) {
        Alert.alert("Could not follow", error.message);
        return;
      }

      setFollowing(true);
    }
  }

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.purple} />
      </View>
    );
  }

  if (!profile) {
    return (
      <View style={styles.loading}>
        <Text style={styles.notFound}>User not found.</Text>
      </View>
    );
  }

  return (
    <Screen>
      <View style={styles.card}>
        {profile.avatar_url ? (
          <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
        ) : (
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {(profile.display_name || profile.username || "N")[0].toUpperCase()}
            </Text>
          </View>
        )}

        <Text style={styles.name}>{profile.display_name || profile.username}</Text>
        <Text style={styles.username}>@{profile.username}</Text>

        {(profile.verified || profile.is_verified) && (
          <Text style={styles.verified}>✓ Verified</Text>
        )}

        <TouchableOpacity style={styles.follow} onPress={toggleFollow}>
          <Text style={styles.followText}>{following ? "Following" : "Follow"}</Text>
        </TouchableOpacity>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1, backgroundColor: colors.bg, alignItems: "center", justifyContent: "center",
  },
  notFound: { color: colors.muted },
  card: {
    backgroundColor: colors.panel, borderColor: colors.border, borderWidth: 1,
    borderRadius: radius.lg, padding: 25, alignItems: "center",
  },
  avatar: {
    width: 86, height: 86, borderRadius: 43, backgroundColor: colors.purple,
    alignItems: "center", justifyContent: "center", marginBottom: 15,
  },
  avatarText: { color: "white", fontSize: 30, fontWeight: "800" },
  name: { color: colors.text, fontSize: 22, fontWeight: "800" },
  username: { color: colors.muted, marginTop: 4 },
  verified: { color: colors.purple, marginTop: 8, fontWeight: "800" },
  follow: {
    marginTop: 18, backgroundColor: colors.purple, borderRadius: radius.md,
    paddingHorizontal: 30, paddingVertical: 12,
  },
  followText: { color: "white", fontWeight: "800" },
});
