import React,{useEffect,useState} from "react";
import { ActivityIndicator,StyleSheet,Text,TouchableOpacity,View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../../components/Screen";
import { supabase } from "../../lib/supabase";
import { colors,radius } from "../../lib/theme";

export default function UserProfile(){
  const {username}=useLocalSearchParams<{username:string}>();const [profile,setProfile]=useState<any>(null);const [following,setFollowing]=useState(false);const [loading,setLoading]=useState(true);
  useEffect(()=>{load();},[username]);
  async function load(){setLoading(true);const {data}=await supabase.from("profiles").select("*").eq("username",username).maybeSingle();setProfile(data);setLoading(false);}
  async function toggleFollow(){const {data:u}=await supabase.auth.getUser();if(!u.user||!profile)return;
    if(following){await supabase.from("follows").delete().eq("follower_id",u.user.id).eq("following_id",profile.id);setFollowing(false);}
    else{await supabase.from("follows").insert({follower_id:u.user.id,following_id:profile.id});setFollowing(true);}
  }
  if(loading)return <View style={styles.loading}><ActivityIndicator color={colors.purple}/></View>;
  if(!profile)return <View style={styles.loading}><Text style={styles.notFound}>User not found.</Text></View>;
  return <Screen><View style={styles.card}><View style={styles.avatar}><Text style={styles.avatarText}>{(profile.display_name||profile.username||"N")[0].toUpperCase()}</Text></View>
    <Text style={styles.name}>{profile.display_name||profile.username}</Text><Text style={styles.username}>@{profile.username}</Text>
    <TouchableOpacity style={styles.follow} onPress={toggleFollow}><Text style={styles.followText}>{following?"Following":"Follow"}</Text></TouchableOpacity>
  </View></Screen>;
}
const styles=StyleSheet.create({
  loading:{flex:1,backgroundColor:colors.bg,alignItems:"center",justifyContent:"center"},notFound:{color:colors.muted},
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.lg,padding:25,alignItems:"center"},
  avatar:{width:86,height:86,borderRadius:43,backgroundColor:colors.purple,alignItems:"center",justifyContent:"center",marginBottom:15},
  avatarText:{color:"white",fontSize:30,fontWeight:"800"},name:{color:colors.text,fontSize:22,fontWeight:"800"},username:{color:colors.muted,marginTop:4},
  follow:{marginTop:18,backgroundColor:colors.purple,borderRadius:radius.md,paddingHorizontal:30,paddingVertical:12},followText:{color:"white",fontWeight:"800"}
});
