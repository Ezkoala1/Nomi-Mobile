import React,{useEffect,useState} from "react";
import { FlatList,KeyboardAvoidingView,Platform,StyleSheet,Text,TextInput,TouchableOpacity,View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { supabase } from "../../lib/supabase";
import { colors,radius } from "../../lib/theme";

export default function Chat(){
  const {id}=useLocalSearchParams<{id:string}>();const [messages,setMessages]=useState<any[]>([]);const [text,setText]=useState("");
  useEffect(()=>{if(id==="demo")return;load();const channel=supabase.channel(`mobile-chat-${id}`)
    .on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:`conversation_id=eq.${id}`},payload=>setMessages(c=>[...c,payload.new])).subscribe();
    return()=>{supabase.removeChannel(channel);};},[id]);
  async function load(){const {data}=await supabase.from("messages").select("*").eq("conversation_id",id).order("created_at",{ascending:true});setMessages(data||[]);}
  async function send(){const content=text.trim();if(!content||id==="demo")return;const {data:u}=await supabase.auth.getUser();if(!u.user)return;
    await supabase.from("messages").insert({conversation_id:id,sender_id:u.user.id,content});setText("");
  }
  return <KeyboardAvoidingView style={styles.page} behavior={Platform.OS==="ios"?"padding":undefined}>
    <FlatList data={messages} keyExtractor={i=>String(i.id)} contentContainerStyle={styles.list}
      renderItem={({item})=><View style={styles.bubble}><Text style={styles.message}>{item.content}</Text></View>}
      ListEmptyComponent={<Text style={styles.empty}>No messages yet. Say hello! ⚡</Text>}/>
    <View style={styles.composer}><TextInput style={styles.input} value={text} onChangeText={setText} placeholder="Write a message..." placeholderTextColor={colors.muted}/>
      <TouchableOpacity style={styles.send} onPress={send}><Text style={styles.sendText}>Send</Text></TouchableOpacity></View>
  </KeyboardAvoidingView>;
}
const styles=StyleSheet.create({
  page:{flex:1,backgroundColor:colors.bg},list:{padding:16,flexGrow:1,justifyContent:"flex-end"},
  bubble:{alignSelf:"flex-start",backgroundColor:colors.panel2,borderRadius:radius.md,padding:12,marginBottom:8,maxWidth:"82%"},
  message:{color:colors.text,lineHeight:20},empty:{color:colors.muted,textAlign:"center",marginBottom:20},
  composer:{flexDirection:"row",gap:8,padding:12,borderTopWidth:1,borderTopColor:colors.border,backgroundColor:colors.panel},
  input:{flex:1,backgroundColor:colors.bg,color:colors.text,borderColor:colors.border,borderWidth:1,borderRadius:radius.md,padding:12},
  send:{backgroundColor:colors.purple,borderRadius:radius.md,paddingHorizontal:15,justifyContent:"center"},sendText:{color:"white",fontWeight:"800"}
});
