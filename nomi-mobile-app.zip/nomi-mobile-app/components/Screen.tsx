import React from "react";
import { ScrollView, StyleSheet, ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "../lib/theme";

export function Screen({children,contentStyle}:{children:React.ReactNode;contentStyle?:ViewStyle}) {
  return <SafeAreaView style={styles.safe}>
    <ScrollView style={styles.scroll} contentContainerStyle={[styles.content,contentStyle]}
      showsVerticalScrollIndicator={false}>{children}</ScrollView>
  </SafeAreaView>;
}
const styles=StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},scroll:{flex:1},content:{padding:20,paddingBottom:40}
});
