import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { colors } from "../lib/theme";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <View style={styles.row}>
      <Text style={styles.bolt}>⚡</Text>
      {!compact && <Text style={styles.name}>Nomi</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 8 },
  bolt: { fontSize: 25, color: colors.purple },
  name: { color: colors.text, fontSize: 24, fontWeight: "800" },
});
