import React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { colors, radius } from "../lib/theme";

export function PostCard({ post }: { post: any }) {
  const profile = Array.isArray(post.profiles) ? post.profiles[0] : post.profiles;
  const username = profile?.username || "user";
  const displayName = profile?.display_name || username;

  return (
    <View style={styles.card}>
      <View style={styles.authorRow}>
        {profile?.avatar_url ? (
          <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
        ) : (
          <View style={styles.avatarFallback}>
            <Text style={styles.avatarText}>{displayName[0]?.toUpperCase() || "N"}</Text>
          </View>
        )}

        <View style={{ flex: 1 }}>
          <Text style={styles.author}>{displayName}</Text>
          <Text style={styles.username}>@{username}</Text>
        </View>

        {(profile?.verified || profile?.is_verified) && (
          <Text style={styles.verified}>✓</Text>
        )}
      </View>

      {!!post.content && <Text style={styles.content}>{post.content}</Text>}

      {!!post.media_url && (
        <Image source={{ uri: post.media_url }} style={styles.media} resizeMode="cover" />
      )}

      <Text style={styles.time}>
        {post.created_at ? new Date(post.created_at).toLocaleString() : ""}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.panel,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: radius.lg,
    padding: 16,
    marginBottom: 12,
  },
  authorRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.panel2 },
  avatarFallback: {
    width: 42, height: 42, borderRadius: 21, backgroundColor: colors.purple,
    alignItems: "center", justifyContent: "center",
  },
  avatarText: { color: "white", fontWeight: "800" },
  author: { color: colors.text, fontWeight: "800" },
  username: { color: colors.muted, marginTop: 2, fontSize: 12 },
  verified: { color: colors.purple, fontSize: 18, fontWeight: "900" },
  content: { color: colors.text, fontSize: 15, lineHeight: 22 },
  media: {
    width: "100%", height: 240, borderRadius: radius.md,
    marginTop: 14, backgroundColor: colors.panel2,
  },
  time: { color: colors.muted, fontSize: 11, marginTop: 12 },
});
