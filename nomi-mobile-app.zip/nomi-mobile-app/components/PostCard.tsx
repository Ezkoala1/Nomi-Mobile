import React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { colors, radius } from "../lib/theme";

export function PostCard({post}:{post:any}) {
  return <View style={styles.card}>
    <Text style={styles.author}>@{post.username||post.author_username||"user"}</Text>
    {!!post.content&&<Text style={styles.content}>{post.content}</Text>}
    {!!post.image_url&&<Image source={{uri:post.image_url}} style={styles.media}/>}
    {!!post.video_url&&<View style={styles.video}><Text style={styles.play}>▶</Text><Text style={styles.videoText}>Video post</Text></View>}
    <Text style={styles.time}>{post.created_at?new Date(post.created_at).toLocaleString():""}</Text>
  </View>;
}
const styles=StyleSheet.create({
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:radius.lg,padding:16,marginBottom:12},
  author:{color:colors.text,fontWeight:"800",marginBottom:10},
  content:{color:colors.text,fontSize:15,lineHeight:22},
  media:{width:"100%",height:240,borderRadius:radius.md,marginTop:14,backgroundColor:colors.panel2},
  video:{height:220,marginTop:14,borderRadius:radius.md,backgroundColor:colors.panel2,alignItems:"center",justifyContent:"center"},
  play:{fontSize:30,color:colors.purple},videoText:{color:colors.muted,marginTop:8},
  time:{color:colors.muted,fontSize:11,marginTop:12}
});
