# Nomi mobile roadmap

The generated app contains the mobile shell and core Nomi screens.

Before release, wire the UI to the exact schema and storage setup already used by your Nomi web app for:
- followed-only feed filtering
- post media uploads
- follow-state loading
- real conversation list
- conversation creation
- profile editing and avatar uploads
- push notifications
- deep links
- production app IDs and store metadata

Keep private/server-only credentials out of the mobile bundle.
